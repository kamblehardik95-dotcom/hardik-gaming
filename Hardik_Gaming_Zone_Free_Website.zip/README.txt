HARDIK GAMING ZONE — FREE WEBSITE

Files:
- index.html: complete responsive website (HTML, CSS, JavaScript all included)

How to publish for free from Android:
1. Extract this ZIP on your phone if needed.
2. Open https://app.netlify.com/drop in Chrome.
3. Netlify Drop usually needs a folder containing index.html. If uploading a folder is awkward on your phone, open Netlify and create a free account, then use the manual deploy/upload option.
4. Upload the website folder (or a ZIP if the page accepts it) and wait for the deploy to finish.
5. Netlify will give you a new public *.netlify.app URL.
6. Keep that URL for your Instagram bio.

Notes:
- Website is static and does not need paid hosting or an API.
- All Subscribe and video buttons link to the YouTube channel URL provided.
- The video cards are category links, not automatically fetched latest-video embeds. You can replace their links with exact video URLs in index.html later.
- A free Netlify subdomain is used; a custom domain is optional and usually costs money.
